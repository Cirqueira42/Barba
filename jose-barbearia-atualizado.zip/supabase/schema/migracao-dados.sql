-- ============================================================
-- JOSÉ BARBEARIA — MIGRAÇÃO DE DADOS (banco antigo -> banco novo)
-- Migra: clientes, agendamentos, fidelidade (estrelas),
--        cupons de desconto e bônus de PEZINHO.
--
-- COMO USAR (rodar no SQL Editor do banco NOVO):
--  1) Rode antes o arquivo de estrutura (josebarbearia-schema.sql).
--  2) Troque os dados da conexão em old_conn() pelos dados do banco ANTIGO.
--  3) Rode este script inteiro. Ele pode ser rodado mais de uma vez
--     (é idempotente: não duplica nada, usa ON CONFLICT / NOT EXISTS).
-- ============================================================

create extension if not exists dblink;

-- ------------------------------------------------------------
-- 1) CONEXÃO COM O BANCO ANTIGO  (EDITE ESTA LINHA)
-- ------------------------------------------------------------
create or replace function public.old_conn()
returns text language sql immutable as $$
  select 'host=HOST_ANTIGO port=5432 dbname=postgres user=postgres password=SENHA_ANTIGA sslmode=require'
$$;

-- ------------------------------------------------------------
-- 2) CLIENTES
-- ------------------------------------------------------------
insert into public.customers (id, phone, name, email, total_appointments, last_appointment_date, notes, created_at, updated_at)
select o.id, regexp_replace(o.phone, '\D', '', 'g'), o.name, o.email,
       coalesce(o.total_appointments, 0), o.last_appointment_date, o.notes,
       coalesce(o.created_at, now()), coalesce(o.updated_at, now())
from dblink(public.old_conn(), $q$
  select id, phone, name, email, total_appointments, last_appointment_date, notes, created_at, updated_at
  from public.customers
$q$) as o(id uuid, phone text, name text, email text, total_appointments int,
          last_appointment_date date, notes text, created_at timestamptz, updated_at timestamptz)
where regexp_replace(coalesce(o.phone,''), '\D', '', 'g') <> ''
on conflict (phone) do update set
  name = excluded.name,
  email = coalesce(excluded.email, public.customers.email),
  total_appointments = greatest(public.customers.total_appointments, excluded.total_appointments),
  last_appointment_date = greatest(coalesce(public.customers.last_appointment_date, '1900-01-01'), coalesce(excluded.last_appointment_date, '1900-01-01')),
  updated_at = now();

-- ------------------------------------------------------------
-- 3) AGENDAMENTOS
--    (validações de formato ficam desligadas durante a carga)
-- ------------------------------------------------------------
alter table public.appointments disable trigger validate_appointment_trigger;

insert into public.appointments (
  id, service_id, service_name, customer_name, customer_email, customer_phone,
  appointment_date, appointment_time, status, barber_id, barber_name,
  seen_by_admin, reminder_sent, created_at
)
select o.id,
       (select s.id from public.services s where lower(s.name) = lower(o.service_name) limit 1),
       o.service_name, o.customer_name, o.customer_email,
       regexp_replace(coalesce(o.customer_phone,''), '\D', '', 'g'),
       o.appointment_date, o.appointment_time, o.status::public.appointment_status,
       (select b.id from public.barbers b where lower(b.name) = lower(coalesce(o.barber_name,'')) limit 1),
       o.barber_name, true, true, coalesce(o.created_at, now())
from dblink(public.old_conn(), $q$
  select id, service_name, customer_name, customer_email, customer_phone,
         appointment_date, appointment_time, status::text, barber_name, created_at
  from public.appointments
$q$) as o(id uuid, service_name text, customer_name text, customer_email text, customer_phone text,
          appointment_date date, appointment_time text, status text, barber_name text, created_at timestamptz)
on conflict (id) do nothing;

alter table public.appointments enable trigger validate_appointment_trigger;

-- ------------------------------------------------------------
-- 4) FIDELIDADE (estrelas / contagem de atendimentos)
--    O gatilho de emissão fica desligado: os benefícios antigos
--    são copiados no passo 5 exatamente como estavam.
-- ------------------------------------------------------------
alter table public.loyalty disable trigger loyalty_issue_rewards;

insert into public.loyalty (id, customer_phone, customer_name, total_services,
                            free_services_earned, free_services_redeemed, created_at, updated_at)
select o.id, regexp_replace(o.customer_phone, '\D', '', 'g'), o.customer_name,
       coalesce(o.total_services,0), coalesce(o.free_services_earned,0),
       coalesce(o.free_services_redeemed,0), coalesce(o.created_at, now()), coalesce(o.updated_at, now())
from dblink(public.old_conn(), $q$
  select id, customer_phone, customer_name, total_services,
         free_services_earned, free_services_redeemed, created_at, updated_at
  from public.loyalty
$q$) as o(id uuid, customer_phone text, customer_name text, total_services int,
          free_services_earned int, free_services_redeemed int, created_at timestamptz, updated_at timestamptz)
where regexp_replace(coalesce(o.customer_phone,''), '\D', '', 'g') <> ''
on conflict (customer_phone) do update set
  total_services = greatest(public.loyalty.total_services, excluded.total_services),
  free_services_earned = greatest(public.loyalty.free_services_earned, excluded.free_services_earned),
  free_services_redeemed = greatest(public.loyalty.free_services_redeemed, excluded.free_services_redeemed),
  customer_name = coalesce(excluded.customer_name, public.loyalty.customer_name),
  updated_at = now();

alter table public.loyalty enable trigger loyalty_issue_rewards;

-- ------------------------------------------------------------
-- 5) BENEFÍCIOS: cupons de desconto + BÔNUS DE PEZINHO
--    Bancos antigos sem a coluna reward_type entram como 'discount';
--    o bloco seguinte identifica os pezinhos pelo código "PZ".
-- ------------------------------------------------------------
insert into public.loyalty_rewards (
  id, customer_phone, customer_name, code, discount_amount, status, milestone,
  reward_type, used_at, used_appointment_id, reserved_appointment_id, created_at, updated_at
)
select o.id, regexp_replace(o.customer_phone, '\D', '', 'g'), o.customer_name, o.code,
       coalesce(o.discount_amount, 0), coalesce(o.status, 'active'), coalesce(o.milestone, 0),
       case
         when coalesce(o.reward_type,'') <> '' then o.reward_type
         when upper(o.code) like 'PZ%' then 'pezinho'
         else 'discount'
       end,
       o.used_at, o.used_appointment_id, o.reserved_appointment_id,
       coalesce(o.created_at, now()), coalesce(o.updated_at, now())
from dblink(public.old_conn(), $q$
  select r.id, r.customer_phone, r.customer_name, r.code, r.discount_amount, r.status, r.milestone,
         coalesce(to_jsonb(r) ->> 'reward_type', '')            as reward_type,
         r.used_at,
         (to_jsonb(r) ->> 'used_appointment_id')::uuid          as used_appointment_id,
         (to_jsonb(r) ->> 'reserved_appointment_id')::uuid      as reserved_appointment_id,
         r.created_at, r.updated_at
  from public.loyalty_rewards r
$q$) as o(id uuid, customer_phone text, customer_name text, code text, discount_amount numeric,
          status text, milestone int, reward_type text, used_at timestamptz,
          used_appointment_id uuid, reserved_appointment_id uuid,
          created_at timestamptz, updated_at timestamptz)
where regexp_replace(coalesce(o.customer_phone,''), '\D', '', 'g') <> ''
on conflict (id) do nothing;

-- Garante que benefícios de pezinho fiquem com o tipo certo
update public.loyalty_rewards
set reward_type = 'pezinho', discount_amount = 0
where upper(code) like 'PZ%' and reward_type <> 'pezinho';

-- Remove vínculos de agendamento que não existem no banco novo
update public.loyalty_rewards r
set reserved_appointment_id = null
where r.reserved_appointment_id is not null
  and not exists (select 1 from public.appointments a where a.id = r.reserved_appointment_id);

update public.loyalty_rewards r
set used_appointment_id = null
where r.used_appointment_id is not null
  and not exists (select 1 from public.appointments a where a.id = r.used_appointment_id);

-- Benefício que estava reservado sem agendamento volta a ficar disponível
update public.loyalty_rewards
set status = 'active'
where status = 'reserved' and reserved_appointment_id is null;

-- ------------------------------------------------------------
-- 6) CLIENTES BLOQUEADOS (opcional, mantém a lista antiga)
-- ------------------------------------------------------------
insert into public.blocked_customers (id, customer_phone, customer_name, reason, created_at)
select o.id, regexp_replace(o.customer_phone, '\D', '', 'g'), o.customer_name, o.reason, coalesce(o.created_at, now())
from dblink(public.old_conn(), $q$
  select id, customer_phone, customer_name, reason, created_at from public.blocked_customers
$q$) as o(id uuid, customer_phone text, customer_name text, reason text, created_at timestamptz)
on conflict (id) do nothing;

-- ------------------------------------------------------------
-- 7) AJUSTA O CONTADOR DO NÚMERO DO AGENDAMENTO
-- ------------------------------------------------------------
select setval('public.appointment_number_seq',
              greatest((select coalesce(max(appointment_number), 0) from public.appointments), 1));

-- ------------------------------------------------------------
-- 8) CONFERÊNCIA — o resultado mostra o que entrou
-- ------------------------------------------------------------
select 'clientes'   as item, count(*) from public.customers
union all select 'agendamentos', count(*) from public.appointments
union all select 'fidelidade', count(*) from public.loyalty
union all select 'cupons de desconto', count(*) from public.loyalty_rewards where reward_type = 'discount'
union all select 'bônus de pezinho', count(*) from public.loyalty_rewards where reward_type = 'pezinho'
union all select 'pezinhos disponíveis', count(*) from public.loyalty_rewards where reward_type = 'pezinho' and status = 'active';

-- ------------------------------------------------------------
-- 9) LIMPEZA — remove a função com a senha do banco antigo
-- ------------------------------------------------------------
drop function if exists public.old_conn();
