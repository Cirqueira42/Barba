-- ============================================================
-- JOSÉ BARBEARIA — Estrutura completa do banco (Supabase)
-- Execute este arquivo inteiro no SQL Editor do seu projeto.
-- ============================================================

create extension if not exists pgcrypto;

-- ------------------------------------------------------------
-- 1) TIPOS
-- ------------------------------------------------------------
do $$ begin
  create type public.app_role as enum ('admin', 'user');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.appointment_status as enum ('pending','confirmed','cancelled','completed');
exception when duplicate_object then null; end $$;

create sequence if not exists public.appointment_number_seq;

-- ------------------------------------------------------------
-- 2) PAPÉIS DE USUÁRIO (ADM)
-- ------------------------------------------------------------
create table if not exists public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

drop policy if exists "Users can read own roles" on public.user_roles;
create policy "Users can read own roles" on public.user_roles
  for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Only admins can insert roles" on public.user_roles;
create policy "Only admins can insert roles" on public.user_roles
  for insert to authenticated with check (public.has_role(auth.uid(),'admin'));
drop policy if exists "Only admins can update roles" on public.user_roles;
create policy "Only admins can update roles" on public.user_roles
  for update to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
drop policy if exists "Only admins can delete roles" on public.user_roles;
create policy "Only admins can delete roles" on public.user_roles
  for delete to authenticated using (public.has_role(auth.uid(),'admin'));

-- vira admin automaticamente ao criar conta com estes e-mails
create or replace function public.handle_admin_signup()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.email in ('josegilmario42@gmail.com', 'admin@josebarbearia.com') then
    insert into public.user_roles (user_id, role) values (new.id, 'admin')
    on conflict (user_id, role) do nothing;
  end if;
  return new;
end; $$;

drop trigger if exists on_auth_user_created_admin on auth.users;
create trigger on_auth_user_created_admin
after insert on auth.users for each row execute function public.handle_admin_signup();

-- ------------------------------------------------------------
-- 3) UTILITÁRIO updated_at
-- ------------------------------------------------------------
create or replace function public.touch_updated_at()
returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end; $$;

-- ------------------------------------------------------------
-- 4) CONFIGURAÇÕES DO APP
-- ------------------------------------------------------------
create table if not exists public.app_settings (
  key text primary key,
  value jsonb not null default 'null'::jsonb,
  updated_at timestamptz not null default now()
);
grant select on public.app_settings to anon;
grant select, insert, update, delete on public.app_settings to authenticated;
grant all on public.app_settings to service_role;
alter table public.app_settings enable row level security;
create policy "Anyone can view settings" on public.app_settings for select to anon, authenticated using (true);
create policy "Only admins can manage settings" on public.app_settings for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- ------------------------------------------------------------
-- 5) SERVIÇOS
-- ------------------------------------------------------------
create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  price numeric not null default 0,
  icon text,
  duration_minutes integer not null default 30,
  image_path text,
  created_at timestamptz not null default now()
);
grant select on public.services to anon;
grant select, insert, update, delete on public.services to authenticated;
grant all on public.services to service_role;
alter table public.services enable row level security;
create policy "Services are viewable by everyone" on public.services for select to anon, authenticated using (true);
create policy "Only admins can manage services" on public.services for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- ------------------------------------------------------------
-- 6) BARBEIROS
-- ------------------------------------------------------------
create table if not exists public.barbers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  enabled boolean not null default false,
  commission_percent integer not null default 50 check (commission_percent between 0 and 100),
  created_at timestamptz not null default now()
);
grant select on public.barbers to anon;
grant select, insert, update, delete on public.barbers to authenticated;
grant all on public.barbers to service_role;
alter table public.barbers enable row level security;
create policy "Anyone can view barbers" on public.barbers for select to anon, authenticated using (true);
create policy "Only admins can manage barbers" on public.barbers for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- ------------------------------------------------------------
-- 7) CLIENTES BLOQUEADOS
-- ------------------------------------------------------------
create table if not exists public.blocked_customers (
  id uuid primary key default gen_random_uuid(),
  customer_phone text not null unique check (customer_phone ~ '^[0-9]{10,11}$'),
  customer_name text,
  reason text,
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.blocked_customers to authenticated;
grant all on public.blocked_customers to service_role;
alter table public.blocked_customers enable row level security;
create policy "Admin manage blocked" on public.blocked_customers for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create or replace function public.is_phone_blocked(_phone text)
returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.blocked_customers
    where customer_phone = regexp_replace(_phone, '\D', '', 'g'));
$$;

-- ------------------------------------------------------------
-- 8) AGENDAMENTOS
-- ------------------------------------------------------------
create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  service_id uuid references public.services(id),
  service_name text not null,
  customer_name text not null,
  customer_email text,
  customer_phone text not null,
  appointment_date date not null,
  appointment_time text not null,
  status public.appointment_status not null default 'pending',
  barber_id uuid references public.barbers(id),
  barber_name text,
  seen_by_admin boolean not null default false,
  appointment_number integer default nextval('public.appointment_number_seq'),
  reminder_sent boolean not null default false,
  created_at timestamptz not null default now()
);
grant insert on public.appointments to anon;
grant select, insert, update, delete on public.appointments to authenticated;
grant all on public.appointments to service_role;
grant usage on sequence public.appointment_number_seq to anon, authenticated, service_role;
alter table public.appointments enable row level security;

create policy "Anyone can create appointments" on public.appointments for insert to anon, authenticated
  with check (status = 'pending' and seen_by_admin = false);
create policy "Admins can view appointments" on public.appointments for select to authenticated
  using (public.has_role(auth.uid(),'admin'));
create policy "Only admins can update appointments" on public.appointments for update to authenticated
  using (public.has_role(auth.uid(),'admin'));
create policy "Only admins can delete appointments" on public.appointments for delete to authenticated
  using (public.has_role(auth.uid(),'admin'));

create index if not exists idx_appointments_date on public.appointments (appointment_date);
create index if not exists idx_appointments_phone on public.appointments (customer_phone);

create or replace function public.validate_appointment()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if char_length(new.customer_name) > 100 then raise exception 'customer_name must be 100 characters or less'; end if;
  if char_length(new.customer_name) < 2 then raise exception 'customer_name must be at least 2 characters'; end if;
  if new.customer_phone !~ '^[0-9]{10,11}$' then raise exception 'customer_phone must be 10-11 digits'; end if;
  if new.customer_email is not null and new.customer_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then
    raise exception 'customer_email must be a valid email address'; end if;
  if new.customer_email is not null and char_length(new.customer_email) > 255 then
    raise exception 'customer_email must be 255 characters or less'; end if;
  if char_length(new.service_name) > 200 then raise exception 'service_name must be 200 characters or less'; end if;
  if new.barber_name is not null and char_length(new.barber_name) > 100 then
    raise exception 'barber_name must be 100 characters or less'; end if;
  return new;
end; $$;

drop trigger if exists validate_appointment_trigger on public.appointments;
create trigger validate_appointment_trigger before insert or update on public.appointments
for each row execute function public.validate_appointment();

-- ------------------------------------------------------------
-- 9) HORÁRIOS BLOQUEADOS
-- ------------------------------------------------------------
create table if not exists public.blocked_slots (
  id uuid primary key default gen_random_uuid(),
  blocked_date date not null,
  blocked_time text,
  reason text,
  created_at timestamptz not null default now()
);
grant select on public.blocked_slots to anon;
grant select, insert, update, delete on public.blocked_slots to authenticated;
grant all on public.blocked_slots to service_role;
alter table public.blocked_slots enable row level security;
create policy "Anyone can view blocked slots" on public.blocked_slots for select to anon, authenticated using (true);
create policy "Only admins can manage blocked slots" on public.blocked_slots for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- ------------------------------------------------------------
-- 10) CLIENTES
-- ------------------------------------------------------------
create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  phone text not null unique,
  name text not null,
  email text,
  total_appointments integer not null default 0,
  last_appointment_date date,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.customers to authenticated;
grant all on public.customers to service_role;
alter table public.customers enable row level security;
create policy "Admins can manage customers" on public.customers for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
drop trigger if exists trg_customers_updated on public.customers;
create trigger trg_customers_updated before update on public.customers
for each row execute function public.touch_updated_at();

-- ------------------------------------------------------------
-- 11) FIDELIDADE
-- ------------------------------------------------------------
create table if not exists public.loyalty (
  id uuid primary key default gen_random_uuid(),
  customer_phone text not null unique,
  customer_name text not null,
  total_services integer not null default 0,
  free_services_earned integer not null default 0,
  free_services_redeemed integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.loyalty to authenticated;
grant all on public.loyalty to service_role;
alter table public.loyalty enable row level security;
create policy "Admins can manage loyalty" on public.loyalty for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create table if not exists public.loyalty_rewards (
  id uuid primary key default gen_random_uuid(),
  customer_phone text not null,
  customer_name text,
  code text not null unique,
  discount_amount numeric not null default 7,
  status text not null default 'active' check (status in ('active','reserved','used','expired')),
  reward_type text not null default 'discount',
  milestone integer not null default 0,
  reserved_appointment_id uuid,
  used_appointment_id uuid,
  used_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.loyalty_rewards to authenticated;
grant all on public.loyalty_rewards to service_role;
alter table public.loyalty_rewards enable row level security;
create policy "Admins can manage loyalty rewards" on public.loyalty_rewards for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
drop trigger if exists trg_loyalty_rewards_updated on public.loyalty_rewards;
create trigger trg_loyalty_rewards_updated before update on public.loyalty_rewards
for each row execute function public.touch_updated_at();

-- ------------------------------------------------------------
-- 12) CAIXA / FINANCEIRO
-- ------------------------------------------------------------
create table if not exists public.cash_entries (
  id uuid primary key default gen_random_uuid(),
  entry_date date not null default ((now() at time zone 'America/Sao_Paulo')::date),
  kind text not null default 'in' check (kind in ('in','out')),
  description text not null,
  amount numeric not null default 0,
  investment_amount numeric not null default 0,
  category text not null default 'atendimento',
  payment_method text,
  appointment_id uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.cash_entries to authenticated;
grant all on public.cash_entries to service_role;
alter table public.cash_entries enable row level security;
create policy "Admins can manage cash entries" on public.cash_entries for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
drop trigger if exists trg_cash_entries_updated on public.cash_entries;
create trigger trg_cash_entries_updated before update on public.cash_entries
for each row execute function public.touch_updated_at();

create table if not exists public.daily_closures (
  id uuid primary key default gen_random_uuid(),
  closure_date date not null unique,
  total_in numeric not null default 0,
  total_out numeric not null default 0,
  investment_total numeric not null default 0,
  net_total numeric not null default 0,
  appointments_closed integer not null default 0,
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.daily_closures to authenticated;
grant all on public.daily_closures to service_role;
alter table public.daily_closures enable row level security;
create policy "Admins can manage daily closures" on public.daily_closures for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create table if not exists public.monthly_summaries (
  id uuid primary key default gen_random_uuid(),
  year integer not null,
  month integer not null,
  gross_total numeric not null default 0,
  services_total numeric not null default 0,
  products_total numeric not null default 0,
  out_total numeric not null default 0,
  appointments_count integer not null default 0,
  manual_count integer not null default 0,
  products_qty integer not null default 0,
  unique_clients integer not null default 0,
  visits integer not null default 0,
  ticket_avg numeric not null default 0,
  top_service text,
  top_product text,
  goal numeric not null default 0,
  updated_at timestamptz not null default now(),
  unique (year, month)
);
grant select, insert, update, delete on public.monthly_summaries to authenticated;
grant all on public.monthly_summaries to service_role;
alter table public.monthly_summaries enable row level security;
create policy "Admins can manage monthly summaries" on public.monthly_summaries for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  description text not null check (char_length(description) between 1 and 200),
  amount numeric not null check (amount >= 0),
  category text not null default 'outros',
  expense_date date not null default ((now() at time zone 'America/Sao_Paulo')::date),
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.expenses to authenticated;
grant all on public.expenses to service_role;
alter table public.expenses enable row level security;
create policy "Admin manage expenses" on public.expenses for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- ------------------------------------------------------------
-- 13) PRODUTOS E VENDAS
-- ------------------------------------------------------------
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  brand text not null,
  name text not null,
  description text,
  price numeric not null default 0,
  image_path text,
  in_stock boolean not null default true,
  stock_qty integer not null default 0,
  min_stock integer not null default 2,
  highlight text,
  display_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select on public.products to anon;
grant select, insert, update, delete on public.products to authenticated;
grant all on public.products to service_role;
alter table public.products enable row level security;
create policy "Anyone can view products" on public.products for select to anon, authenticated using (true);
create policy "Only admins can manage products" on public.products for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create table if not exists public.product_sales (
  id uuid primary key default gen_random_uuid(),
  product_id uuid references public.products(id),
  product_name text not null,
  brand text,
  qty integer not null default 1,
  unit_price numeric not null default 0,
  total numeric not null default 0,
  sale_date date not null default ((now() at time zone 'America/Sao_Paulo')::date),
  cash_entry_id uuid references public.cash_entries(id),
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.product_sales to authenticated;
grant all on public.product_sales to service_role;
alter table public.product_sales enable row level security;
create policy "Admins can manage product sales" on public.product_sales for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- ------------------------------------------------------------
-- 14) CUPONS
-- ------------------------------------------------------------
create table if not exists public.coupons (
  id uuid primary key default gen_random_uuid(),
  code text not null unique check (char_length(code) between 3 and 30),
  discount_percent integer not null default 10 check (discount_percent between 1 and 100),
  valid_until date,
  max_uses integer,
  uses_count integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.coupons to authenticated;
grant all on public.coupons to service_role;
alter table public.coupons enable row level security;
create policy "Admin manage coupons" on public.coupons for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- ------------------------------------------------------------
-- 15) AVALIAÇÕES
-- ------------------------------------------------------------
create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  appointment_id uuid references public.appointments(id),
  customer_name text not null,
  customer_phone text,
  rating integer not null,
  comment text,
  approved boolean not null default false,
  created_at timestamptz not null default now()
);
grant insert on public.reviews to anon;
grant select, insert, update, delete on public.reviews to authenticated;
grant all on public.reviews to service_role;
alter table public.reviews enable row level security;
create policy "Anyone can create reviews" on public.reviews for insert to anon, authenticated with check (true);
create policy "Only admins can view reviews" on public.reviews for select to authenticated
  using (public.has_role(auth.uid(),'admin'));
create policy "Only admins can update reviews" on public.reviews for update to authenticated
  using (public.has_role(auth.uid(),'admin'));
create policy "Only admins can delete reviews" on public.reviews for delete to authenticated
  using (public.has_role(auth.uid(),'admin'));

create or replace function public.validate_review()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.rating < 1 or new.rating > 5 then raise exception 'rating must be between 1 and 5'; end if;
  if char_length(new.customer_name) < 2 or char_length(new.customer_name) > 100 then
    raise exception 'customer_name must be 2-100 characters'; end if;
  if new.comment is not null and char_length(new.comment) > 500 then
    raise exception 'comment must be 500 characters or less'; end if;
  if not public.has_role(auth.uid(), 'admin') then new.approved := false; end if;
  return new;
end; $$;

drop trigger if exists validate_review_trigger on public.reviews;
create trigger validate_review_trigger before insert or update on public.reviews
for each row execute function public.validate_review();

-- ------------------------------------------------------------
-- 16) GALERIA E FUNDOS
-- ------------------------------------------------------------
create table if not exists public.gallery_photos (
  id uuid primary key default gen_random_uuid(),
  storage_path text not null,
  caption text,
  display_order integer not null default 0,
  created_at timestamptz not null default now()
);
grant select on public.gallery_photos to anon;
grant select, insert, update, delete on public.gallery_photos to authenticated;
grant all on public.gallery_photos to service_role;
alter table public.gallery_photos enable row level security;
create policy "Anyone can view gallery photos" on public.gallery_photos for select to anon, authenticated using (true);
create policy "Only admins can manage gallery photos" on public.gallery_photos for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create table if not exists public.hero_backgrounds (
  id uuid primary key default gen_random_uuid(),
  storage_path text not null,
  display_order integer not null default 0,
  created_at timestamptz not null default now()
);
grant select on public.hero_backgrounds to anon;
grant select, insert, update, delete on public.hero_backgrounds to authenticated;
grant all on public.hero_backgrounds to service_role;
alter table public.hero_backgrounds enable row level security;
create policy "Anyone can view hero backgrounds" on public.hero_backgrounds for select to anon, authenticated using (true);
create policy "Only admins can manage hero backgrounds" on public.hero_backgrounds for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- ------------------------------------------------------------
-- 17) FUNÇÕES PÚBLICAS USADAS PELO APP (RPC)
-- ------------------------------------------------------------
create or replace function public.get_booked_slots(_date date)
returns table(appointment_time text, service_name text, barber_id uuid)
language sql stable security definer set search_path = public as $$
  select a.appointment_time, a.service_name, a.barber_id
  from public.appointments a
  where a.appointment_date = _date and a.status in ('pending','confirmed');
$$;

create or replace function public.create_appointment(
  _service_id uuid, _service_name text, _customer_name text, _customer_phone text,
  _appointment_date date, _appointment_time text, _barber_id uuid default null,
  _barber_name text default null, _customer_email text default null)
returns table(appointment_id uuid, appointment_number integer, barber_name text)
language plpgsql security definer set search_path = public as $$
declare p text; rec public.appointments%rowtype;
begin
  p := regexp_replace(coalesce(_customer_phone,''), '\D', '', 'g');
  if public.is_phone_blocked(p) then raise exception 'blocked_customer'; end if;
  insert into public.appointments (service_id, service_name, customer_name, customer_email, customer_phone,
    appointment_date, appointment_time, barber_id, barber_name, status, seen_by_admin)
  values (_service_id, _service_name, trim(_customer_name),
    nullif(trim(coalesce(_customer_email,'')),''), p, _appointment_date, _appointment_time,
    _barber_id, nullif(trim(coalesce(_barber_name,'')),''), 'pending', false)
  returning * into rec;
  return query select rec.id, rec.appointment_number, rec.barber_name;
end; $$;

create or replace function public.lookup_customer_by_phone(_phone text)
returns table(customer_name text, customer_email text)
language sql stable security definer set search_path = public as $$
  select c.name, c.email from public.customers c
  where c.phone = regexp_replace(_phone, '\D', '', 'g')
  union all
  select a.customer_name, a.customer_email from public.appointments a
  where a.customer_phone = regexp_replace(_phone, '\D', '', 'g')
    and not exists (select 1 from public.customers c2 where c2.phone = regexp_replace(_phone, '\D', '', 'g'))
  order by 1 limit 1;
$$;

create or replace function public.upsert_customer(_phone text, _name text, _email text default null, _date date default null)
returns void language plpgsql security definer set search_path = public as $$
declare p text;
begin
  p := regexp_replace(coalesce(_phone,''), '\D', '', 'g');
  if p !~ '^[0-9]{10,11}$' then return; end if;
  if _name is null or char_length(trim(_name)) < 2 or char_length(_name) > 100 then return; end if;
  insert into public.customers (phone, name, email, total_appointments, last_appointment_date)
  values (p, trim(_name), nullif(trim(coalesce(_email,'')),''), 1,
          coalesce(_date, (now() at time zone 'America/Sao_Paulo')::date))
  on conflict (phone) do update set
    name = excluded.name,
    email = coalesce(excluded.email, public.customers.email),
    total_appointments = public.customers.total_appointments + 1,
    last_appointment_date = excluded.last_appointment_date,
    updated_at = now();
end; $$;

create or replace function public.validate_coupon(_code text)
returns table(valid boolean, discount_percent integer, message text)
language plpgsql stable security definer set search_path = public as $$
declare c public.coupons%rowtype;
begin
  select * into c from public.coupons where upper(code) = upper(_code);
  if not found then return query select false, 0, 'Cupom não encontrado'::text; return; end if;
  if not c.active then return query select false, 0, 'Cupom inativo'::text; return; end if;
  if c.valid_until is not null and c.valid_until < (now() at time zone 'America/Sao_Paulo')::date then
    return query select false, 0, 'Cupom expirado'::text; return; end if;
  if c.max_uses is not null and c.uses_count >= c.max_uses then
    return query select false, 0, 'Cupom esgotado'::text; return; end if;
  return query select true, c.discount_percent, 'Cupom válido'::text;
end; $$;

-- --- Fidelidade: emissão, consulta, reserva e uso -----------------
create or replace function public.issue_loyalty_rewards(_phone text, _name text default null)
returns integer language plpgsql security definer set search_path = public as $$
declare p text; total int; earned int; existing int; i int; new_code text; val numeric;
begin
  p := regexp_replace(coalesce(_phone,''), '\D', '', 'g');
  if p = '' then return 0; end if;
  select coalesce(total_services,0) into total from public.loyalty where customer_phone = p;
  if total is null then return 0; end if;
  select coalesce((value #>> '{}')::numeric, 7) into val from public.app_settings where key = 'loyalty_reward_value';
  val := coalesce(val, 7);
  earned := floor(total / 10);
  select count(*) into existing from public.loyalty_rewards where customer_phone = p and reward_type = 'discount';
  i := existing;
  while i < earned loop
    i := i + 1;
    loop
      new_code := 'JB' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
      exit when not exists (select 1 from public.loyalty_rewards where code = new_code);
    end loop;
    insert into public.loyalty_rewards (customer_phone, customer_name, code, milestone, discount_amount, reward_type)
    values (p, _name, new_code, i * 10, val, 'discount');
  end loop;
  return earned - existing;
end; $$;

create or replace function public.issue_pezinho_rewards(_phone text, _name text default null)
returns integer language plpgsql security definer set search_path = public as $$
declare p text; total int; earned int; existing int; i int; new_code text;
begin
  p := regexp_replace(coalesce(_phone,''), '\D', '', 'g');
  if p = '' then return 0; end if;
  select coalesce(total_services,0) into total from public.loyalty where customer_phone = p;
  if total is null then return 0; end if;
  earned := floor((total + 5) / 10);
  select count(*) into existing from public.loyalty_rewards where customer_phone = p and reward_type = 'pezinho';
  i := existing;
  while i < earned loop
    i := i + 1;
    loop
      new_code := 'PZ' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
      exit when not exists (select 1 from public.loyalty_rewards where code = new_code);
    end loop;
    insert into public.loyalty_rewards (customer_phone, customer_name, code, milestone, discount_amount, reward_type)
    values (p, _name, new_code, (i * 10) - 5, 0, 'pezinho');
  end loop;
  return earned - existing;
end; $$;

create or replace function public.trg_issue_loyalty_rewards()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.issue_loyalty_rewards(new.customer_phone, new.customer_name);
  perform public.issue_pezinho_rewards(new.customer_phone, new.customer_name);
  return new;
end; $$;

drop trigger if exists loyalty_issue_rewards on public.loyalty;
create trigger loyalty_issue_rewards after insert or update on public.loyalty
for each row execute function public.trg_issue_loyalty_rewards();

create or replace function public.handle_loyalty_change(_appointment_id uuid, _delta integer)
returns integer language plpgsql security definer set search_path = public as $$
declare
  appt_record record; normalized_phone text; other_eligible_count integer;
  service_price numeric; rewards_issued integer := 0;
begin
  select a.customer_phone, a.appointment_date, a.customer_name, a.status, a.service_name
  into appt_record from public.appointments a where a.id = _appointment_id;
  if not found then return 0; end if;

  normalized_phone := regexp_replace(coalesce(appt_record.customer_phone, ''), '\D', '', 'g');
  if normalized_phone = '' then return 0; end if;

  select coalesce(s.price, 0) into service_price from public.services s
  where lower(s.name) = lower(appt_record.service_name) order by s.created_at desc limit 1;
  service_price := coalesce(service_price, 0);
  if service_price < 30 then return 0; end if;

  select count(*) into other_eligible_count
  from public.appointments a
  join public.services s on lower(s.name) = lower(a.service_name)
  where regexp_replace(coalesce(a.customer_phone, ''), '\D', '', 'g') = normalized_phone
    and a.appointment_date = appt_record.appointment_date
    and a.status = 'completed' and s.price >= 30 and a.id <> _appointment_id;

  if _delta > 0 then
    if appt_record.status <> 'completed' or other_eligible_count > 0 then return 0; end if;
    insert into public.loyalty (customer_phone, customer_name, total_services, free_services_earned)
    values (normalized_phone, appt_record.customer_name, 1, 0)
    on conflict (customer_phone) do update set
      total_services = public.loyalty.total_services + 1,
      free_services_earned = floor((public.loyalty.total_services + 1) / 10),
      customer_name = coalesce(appt_record.customer_name, public.loyalty.customer_name),
      updated_at = now();
    rewards_issued := public.issue_loyalty_rewards(normalized_phone, appt_record.customer_name);
    return coalesce(rewards_issued, 0);
  end if;

  if _delta < 0 and other_eligible_count = 0 then
    update public.loyalty
    set total_services = greatest(total_services - 1, 0),
        free_services_earned = floor(greatest(total_services - 1, 0) / 10),
        updated_at = now()
    where customer_phone = normalized_phone;
  end if;
  return 0;
end; $$;

create or replace function public.get_loyalty_progress(_phone text)
returns table(total_services integer, free_services_earned integer, free_services_redeemed integer,
  available integer, progress integer, goal integer, has_reward boolean,
  pezinho_available integer, has_pezinho boolean)
language sql stable security definer set search_path = public as $$
  select
    coalesce(l.total_services, 0)::int,
    coalesce(l.free_services_earned, 0)::int,
    coalesce(l.free_services_redeemed, 0)::int,
    (select count(*) from public.loyalty_rewards r where r.customer_phone = q.p and r.status = 'active' and r.reward_type = 'discount')::int,
    (coalesce(l.total_services, 0) % 10)::int,
    10,
    exists (select 1 from public.loyalty_rewards r where r.customer_phone = q.p and r.status = 'active' and r.reward_type = 'discount'),
    (select count(*) from public.loyalty_rewards r where r.customer_phone = q.p and r.status = 'active' and r.reward_type = 'pezinho')::int,
    exists (select 1 from public.loyalty_rewards r where r.customer_phone = q.p and r.status = 'active' and r.reward_type = 'pezinho')
  from (select regexp_replace(_phone, '\D', '', 'g') as p) q
  left join public.loyalty l on l.customer_phone = q.p;
$$;

create or replace function public.get_pezinho_status(_phone text)
returns table(available integer, expires_at timestamptz, days_left integer, just_expired boolean)
language plpgsql security definer set search_path = public as $$
declare p text; d int; exp_count int := 0; nxt timestamptz;
begin
  p := regexp_replace(coalesce(_phone,''), '\D', '', 'g');
  if p = '' then return query select 0, null::timestamptz, 0, false; return; end if;

  select (value #>> '{}')::int into d from public.app_settings where key = 'loyalty_validity_days';
  d := coalesce(d, 0);

  if d > 0 then
    update public.loyalty_rewards set status = 'expired', updated_at = now()
    where customer_phone = p and reward_type = 'pezinho' and status = 'active'
      and created_at < now() - make_interval(days => d);
    get diagnostics exp_count = row_count;
    select min(r.created_at) + make_interval(days => d) into nxt
    from public.loyalty_rewards r
    where r.customer_phone = p and r.reward_type = 'pezinho' and r.status = 'active';
  else
    nxt := null;
  end if;

  return query
  select (select count(*)::int from public.loyalty_rewards r
          where r.customer_phone = p and r.reward_type = 'pezinho' and r.status = 'active'),
         nxt,
         case when nxt is null then 0 else greatest(0, ceil(extract(epoch from (nxt - now())) / 86400))::int end,
         exp_count > 0;
end; $$;

create or replace function public.get_active_reward(_phone text)
returns table(code text, discount_amount numeric)
language sql stable security definer set search_path = public as $$
  select r.code, r.discount_amount from public.loyalty_rewards r
  where r.customer_phone = regexp_replace(_phone, '\D', '', 'g')
    and r.status = 'active' and r.reward_type = 'discount'
  order by r.created_at asc limit 1;
$$;

create or replace function public.get_reward_by_code(_phone text, _code text)
returns table(code text, discount_amount numeric, status text)
language sql stable security definer set search_path = public as $$
  select r.code, r.discount_amount, r.status from public.loyalty_rewards r
  where r.customer_phone = regexp_replace(coalesce(_phone,''), '\D', '', 'g')
    and upper(r.code) = upper(trim(coalesce(_code,''))) and r.reward_type = 'discount'
  limit 1;
$$;

create or replace function public.get_appointment_reward(_appointment_id uuid)
returns table(code text, discount_amount numeric, status text)
language sql stable security definer set search_path = public as $$
  select r.code, r.discount_amount, r.status from public.loyalty_rewards r
  where r.reserved_appointment_id = _appointment_id or r.used_appointment_id = _appointment_id
  limit 1;
$$;

create or replace function public.reserve_loyalty_reward(_phone text, _code text, _appointment_id uuid)
returns table(valid boolean, message text)
language plpgsql security definer set search_path = public as $$
declare p text; r public.loyalty_rewards%rowtype;
begin
  p := regexp_replace(coalesce(_phone,''), '\D', '', 'g');
  select * into r from public.loyalty_rewards
  where customer_phone = p and upper(code) = upper(trim(coalesce(_code,''))) for update;
  if not found then return query select false, 'Código inválido para este telefone'::text; return; end if;
  if r.status = 'reserved' and r.reserved_appointment_id = _appointment_id then
    return query select true, 'Benefício já reservado para este agendamento'::text; return; end if;
  if r.status <> 'active' then
    return query select false, 'Este benefício não está disponível'::text; return; end if;
  update public.loyalty_rewards set status = 'reserved', reserved_appointment_id = _appointment_id, updated_at = now()
  where id = r.id;
  return query select true, 'Benefício reservado para este agendamento'::text;
end; $$;

create or replace function public.reserve_pezinho_reward(_phone text, _appointment_id uuid)
returns table(valid boolean, code text, message text)
language plpgsql security definer set search_path = public as $$
declare p text; r public.loyalty_rewards%rowtype;
begin
  p := regexp_replace(coalesce(_phone,''), '\D', '', 'g');
  select * into r from public.loyalty_rewards
  where customer_phone = p and reward_type = 'pezinho' and status = 'reserved'
    and reserved_appointment_id = _appointment_id limit 1;
  if found then return query select true, r.code, 'Bônus já reservado para este agendamento'::text; return; end if;

  select * into r from public.loyalty_rewards
  where customer_phone = p and reward_type = 'pezinho' and status = 'active'
  order by created_at asc limit 1 for update;
  if not found then return query select false, null::text, 'Nenhum bônus de pezinho disponível'::text; return; end if;

  update public.loyalty_rewards set status = 'reserved', reserved_appointment_id = _appointment_id, updated_at = now()
  where id = r.id;
  return query select true, r.code, 'Bônus de pezinho reservado'::text;
end; $$;

create or replace function public.release_loyalty_reward(_appointment_id uuid)
returns boolean language plpgsql security definer set search_path = public as $$
declare n int;
begin
  update public.loyalty_rewards set status = 'active', reserved_appointment_id = null, updated_at = now()
  where reserved_appointment_id = _appointment_id and status = 'reserved';
  get diagnostics n = row_count;
  return n > 0;
end; $$;

create or replace function public.consume_loyalty_reward(_appointment_id uuid)
returns table(consumed boolean, code text, discount_amount numeric)
language plpgsql security definer set search_path = public as $$
declare r public.loyalty_rewards%rowtype;
begin
  select * into r from public.loyalty_rewards
  where reserved_appointment_id = _appointment_id and status = 'reserved' for update;
  if not found then return query select false, null::text, null::numeric; return; end if;
  update public.loyalty_rewards
  set status = 'used', used_at = now(), used_appointment_id = _appointment_id, updated_at = now()
  where id = r.id;
  update public.loyalty set free_services_redeemed = free_services_redeemed + 1, updated_at = now()
  where customer_phone = r.customer_phone;
  return query select true, r.code, r.discount_amount;
end; $$;

create or replace function public.redeem_loyalty_code(_phone text, _code text)
returns table(valid boolean, message text)
language plpgsql security definer set search_path = public as $$
declare p text; r public.loyalty_rewards%rowtype;
begin
  p := regexp_replace(coalesce(_phone,''), '\D', '', 'g');
  select * into r from public.loyalty_rewards
  where upper(code) = upper(trim(coalesce(_code,''))) and customer_phone = p;
  if not found then return query select false, 'Código inválido para este telefone'::text; return; end if;
  if r.status <> 'active' then return query select false, 'Este código já foi utilizado'::text; return; end if;
  update public.loyalty_rewards set status = 'used', used_at = now(), updated_at = now() where id = r.id;
  update public.loyalty set free_services_redeemed = free_services_redeemed + 1, updated_at = now()
  where customer_phone = p;
  return query select true, 'Desconto exclusivo aplicado'::text;
end; $$;

create or replace function public.redeem_pezinho_reward(_phone text)
returns table(valid boolean, message text)
language plpgsql security definer set search_path = public as $$
declare p text; r public.loyalty_rewards%rowtype;
begin
  p := regexp_replace(coalesce(_phone,''), '\D', '', 'g');
  select * into r from public.loyalty_rewards
  where customer_phone = p and reward_type = 'pezinho' and status = 'active'
  order by created_at asc limit 1 for update;
  if not found then return query select false, 'Nenhum pezinho disponível'::text; return; end if;
  update public.loyalty_rewards set status = 'used', used_at = now(), updated_at = now() where id = r.id;
  return query select true, 'Pezinho de cabelo grátis utilizado'::text;
end; $$;

create or replace function public.get_top_product()
returns table(product_id uuid, product_name text, total_qty integer)
language sql stable security definer set search_path = public as $$
  select s.product_id, s.product_name, sum(s.qty)::int as total_qty
  from public.product_sales s
  group by s.product_id, s.product_name
  order by total_qty desc limit 1;
$$;

-- Permissões de execução das RPCs usadas pelo site público
grant execute on function public.get_booked_slots(date) to anon, authenticated;
grant execute on function public.create_appointment(uuid,text,text,text,date,text,uuid,text,text) to anon, authenticated;
grant execute on function public.lookup_customer_by_phone(text) to anon, authenticated;
grant execute on function public.upsert_customer(text,text,text,date) to anon, authenticated;
grant execute on function public.validate_coupon(text) to anon, authenticated;
grant execute on function public.get_loyalty_progress(text) to anon, authenticated;
grant execute on function public.get_pezinho_status(text) to anon, authenticated;
grant execute on function public.get_active_reward(text) to anon, authenticated;
grant execute on function public.get_reward_by_code(text,text) to anon, authenticated;
grant execute on function public.get_appointment_reward(uuid) to anon, authenticated;
grant execute on function public.reserve_loyalty_reward(text,text,uuid) to anon, authenticated;
grant execute on function public.reserve_pezinho_reward(text,uuid) to anon, authenticated;
grant execute on function public.release_loyalty_reward(uuid) to anon, authenticated;
grant execute on function public.is_phone_blocked(text) to anon, authenticated;

-- ------------------------------------------------------------
-- 18) STORAGE (buckets públicos) + políticas
-- ------------------------------------------------------------
insert into storage.buckets (id, name, public) values
  ('gallery','gallery',true), ('products','products',true), ('services','services',true)
on conflict (id) do nothing;

drop policy if exists "Public read barbearia buckets" on storage.objects;
create policy "Public read barbearia buckets" on storage.objects for select
  using (bucket_id in ('gallery','products','services'));

drop policy if exists "Admins manage barbearia buckets" on storage.objects;
create policy "Admins manage barbearia buckets" on storage.objects for all to authenticated
  using (bucket_id in ('gallery','products','services') and public.has_role(auth.uid(),'admin'))
  with check (bucket_id in ('gallery','products','services') and public.has_role(auth.uid(),'admin'));

-- ------------------------------------------------------------
-- 19) CONFIGURAÇÕES PADRÃO
-- ------------------------------------------------------------
insert into public.app_settings (key, value) values
  ('loyalty_reward_value', to_jsonb(7)),
  ('loyalty_validity_days', to_jsonb(0))
on conflict (key) do nothing;

-- FIM
