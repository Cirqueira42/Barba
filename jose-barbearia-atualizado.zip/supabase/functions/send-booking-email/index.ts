import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';

const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');
const OWNER_EMAIL = 'josegilmario42@gmail.com';

type Body = {
  appointmentNumber?: number;
  customerName?: string;
  customerPhone?: string;
  serviceName?: string;
  date?: string;
  time?: string;
  barberName?: string;
  price?: string;
  paymentMethod?: string;
};

const esc = (v: unknown) =>
  String(v ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .slice(0, 300);

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    if (!RESEND_API_KEY) {
      return new Response(JSON.stringify({ error: 'RESEND_API_KEY não configurada' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const body = (await req.json()) as Body;
    if (!body?.customerName || !body?.date || !body?.time || !body?.serviceName) {
      return new Response(JSON.stringify({ error: 'Dados do agendamento incompletos' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const rows: [string, unknown][] = [
      ['Cliente', body.customerName],
      ['Telefone', body.customerPhone],
      ['Serviço', body.serviceName],
      ['Data', body.date],
      ['Horário', body.time],
      ['Barbeiro', body.barberName],
      ['Valor', body.price],
      ['Pagamento', body.paymentMethod],
    ];

    const html = `
      <div style="font-family:Arial,sans-serif;background:#ffffff;padding:24px;color:#111">
        <h2 style="margin:0 0 4px;color:#b8860b">💈 Novo agendamento${body.appointmentNumber ? ` #${esc(body.appointmentNumber)}` : ''}</h2>
        <p style="margin:0 0 16px;color:#555">José Barbearia — agendamento recebido pelo aplicativo.</p>
        <table style="border-collapse:collapse;width:100%;max-width:480px">
          ${rows
            .filter(([, v]) => v !== undefined && v !== null && String(v).trim() !== '')
            .map(
              ([k, v]) =>
                `<tr><td style="padding:6px 10px;border:1px solid #eee;font-weight:bold">${k}</td><td style="padding:6px 10px;border:1px solid #eee">${esc(v)}</td></tr>`,
            )
            .join('')}
        </table>
      </div>`;

    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'José Barbearia <onboarding@resend.dev>',
        to: [OWNER_EMAIL],
        subject: `💈 Novo agendamento — ${body.customerName} • ${body.date} ${body.time}`,
        html,
      }),
    });

    if (!res.ok) {
      const details = await res.text();
      console.error(`Resend falhou [${res.status}]: ${details}`);
      return new Response(JSON.stringify({ error: 'Falha ao enviar e-mail', status: res.status, details }), {
        status: res.status,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ sent: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (e) {
    console.error('send-booking-email error:', e);
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
