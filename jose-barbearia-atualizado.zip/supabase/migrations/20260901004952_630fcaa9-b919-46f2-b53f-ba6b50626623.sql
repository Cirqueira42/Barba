CREATE OR REPLACE FUNCTION public.get_pezinho_status(_phone text)
RETURNS TABLE(available integer, expires_at timestamptz, days_left integer, just_expired boolean)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE p text; d int; exp_count int := 0; nxt timestamptz;
BEGIN
  p := regexp_replace(coalesce(_phone,''), '\D', '', 'g');
  IF p = '' THEN
    RETURN QUERY SELECT 0, NULL::timestamptz, 0, false; RETURN;
  END IF;

  SELECT (value #>> '{}')::int INTO d FROM public.app_settings WHERE key = 'loyalty_validity_days';
  d := coalesce(d, 0);

  IF d > 0 THEN
    UPDATE public.loyalty_rewards
    SET status = 'expired', updated_at = now()
    WHERE customer_phone = p AND reward_type = 'pezinho' AND status = 'active'
      AND created_at < now() - make_interval(days => d);
    GET DIAGNOSTICS exp_count = ROW_COUNT;

    SELECT min(r.created_at) + make_interval(days => d) INTO nxt
    FROM public.loyalty_rewards r
    WHERE r.customer_phone = p AND r.reward_type = 'pezinho' AND r.status = 'active';
  ELSE
    nxt := NULL;
  END IF;

  RETURN QUERY
  SELECT (SELECT count(*)::int FROM public.loyalty_rewards r
          WHERE r.customer_phone = p AND r.reward_type = 'pezinho' AND r.status = 'active'),
         nxt,
         CASE WHEN nxt IS NULL THEN 0
              ELSE greatest(0, ceil(extract(epoch FROM (nxt - now())) / 86400))::int END,
         exp_count > 0;
END;
$$;