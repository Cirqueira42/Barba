
CREATE OR REPLACE FUNCTION public.get_pezinho_status(_phone text)
RETURNS TABLE(available integer, expires_at timestamptz, days_left integer, just_expired boolean)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE p text; d int; exp_count int := 0; nxt timestamptz;
BEGIN
  p := regexp_replace(coalesce(_phone,''), '\D', '', 'g');
  IF p = '' THEN
    RETURN QUERY SELECT 0, NULL::timestamptz, 0, false; RETURN;
  END IF;

  SELECT nullif((value #>> '{}')::int, 0) INTO d FROM public.app_settings WHERE key = 'loyalty_validity_days';
  d := coalesce(d, 10);

  UPDATE public.loyalty_rewards
  SET status = 'expired', updated_at = now()
  WHERE customer_phone = p AND reward_type = 'pezinho' AND status = 'active'
    AND created_at < now() - make_interval(days => d);
  GET DIAGNOSTICS exp_count = ROW_COUNT;

  SELECT min(r.created_at) + make_interval(days => d) INTO nxt
  FROM public.loyalty_rewards r
  WHERE r.customer_phone = p AND r.reward_type = 'pezinho' AND r.status = 'active';

  RETURN QUERY
  SELECT (SELECT count(*)::int FROM public.loyalty_rewards r
          WHERE r.customer_phone = p AND r.reward_type = 'pezinho' AND r.status = 'active'),
         nxt,
         CASE WHEN nxt IS NULL THEN 0
              ELSE greatest(0, ceil(extract(epoch FROM (nxt - now())) / 86400))::int END,
         exp_count > 0;
END;
$$;

CREATE OR REPLACE FUNCTION public.reserve_pezinho_reward(_phone text, _appointment_id uuid)
RETURNS TABLE(valid boolean, code text, message text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE p text; r public.loyalty_rewards%ROWTYPE;
BEGIN
  p := regexp_replace(coalesce(_phone,''), '\D', '', 'g');

  SELECT * INTO r FROM public.loyalty_rewards
  WHERE customer_phone = p AND reward_type = 'pezinho'
    AND status = 'reserved' AND reserved_appointment_id = _appointment_id
  LIMIT 1;
  IF FOUND THEN
    RETURN QUERY SELECT true, r.code, 'Bônus já reservado para este agendamento'::text; RETURN;
  END IF;

  SELECT * INTO r FROM public.loyalty_rewards
  WHERE customer_phone = p AND reward_type = 'pezinho' AND status = 'active'
  ORDER BY created_at ASC LIMIT 1 FOR UPDATE;

  IF NOT FOUND THEN
    RETURN QUERY SELECT false, NULL::text, 'Nenhum bônus de pezinho disponível'::text; RETURN;
  END IF;

  UPDATE public.loyalty_rewards
  SET status = 'reserved', reserved_appointment_id = _appointment_id, updated_at = now()
  WHERE id = r.id;

  RETURN QUERY SELECT true, r.code, 'Bônus de pezinho reservado'::text;
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_pezinho_status(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.reserve_pezinho_reward(text, uuid) TO anon, authenticated;
