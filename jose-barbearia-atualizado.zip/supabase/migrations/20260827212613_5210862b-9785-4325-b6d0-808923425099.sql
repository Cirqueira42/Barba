ALTER TABLE public.loyalty_rewards ADD COLUMN IF NOT EXISTS reward_type text NOT NULL DEFAULT 'discount';

-- mantém a lógica de desconto existente, apenas contando somente recompensas de desconto
CREATE OR REPLACE FUNCTION public.issue_loyalty_rewards(_phone text, _name text DEFAULT NULL::text)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  p text; total int; earned int; existing int; i int; new_code text; val numeric;
BEGIN
  p := regexp_replace(coalesce(_phone,''), '\D', '', 'g');
  IF p = '' THEN RETURN 0; END IF;

  SELECT coalesce(total_services,0) INTO total FROM public.loyalty WHERE customer_phone = p;
  IF total IS NULL THEN RETURN 0; END IF;

  SELECT coalesce((value #>> '{}')::numeric, 7) INTO val
  FROM public.app_settings WHERE key = 'loyalty_reward_value';
  val := coalesce(val, 7);

  earned := floor(total / 10);
  SELECT count(*) INTO existing FROM public.loyalty_rewards WHERE customer_phone = p AND reward_type = 'discount';

  i := existing;
  WHILE i < earned LOOP
    i := i + 1;
    LOOP
      new_code := 'JB' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
      EXIT WHEN NOT EXISTS (SELECT 1 FROM public.loyalty_rewards WHERE code = new_code);
    END LOOP;
    INSERT INTO public.loyalty_rewards (customer_phone, customer_name, code, milestone, discount_amount, reward_type)
    VALUES (p, _name, new_code, i * 10, val, 'discount');
  END LOOP;

  RETURN earned - existing;
END;
$function$;

-- NOVO: bônus do 5º atendimento (5, 15, 25, ...)
CREATE OR REPLACE FUNCTION public.issue_pezinho_rewards(_phone text, _name text DEFAULT NULL::text)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  p text; total int; earned int; existing int; i int; new_code text;
BEGIN
  p := regexp_replace(coalesce(_phone,''), '\D', '', 'g');
  IF p = '' THEN RETURN 0; END IF;

  SELECT coalesce(total_services,0) INTO total FROM public.loyalty WHERE customer_phone = p;
  IF total IS NULL THEN RETURN 0; END IF;

  earned := floor((total + 5) / 10);
  SELECT count(*) INTO existing FROM public.loyalty_rewards WHERE customer_phone = p AND reward_type = 'pezinho';

  i := existing;
  WHILE i < earned LOOP
    i := i + 1;
    LOOP
      new_code := 'PZ' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
      EXIT WHEN NOT EXISTS (SELECT 1 FROM public.loyalty_rewards WHERE code = new_code);
    END LOOP;
    INSERT INTO public.loyalty_rewards (customer_phone, customer_name, code, milestone, discount_amount, reward_type)
    VALUES (p, _name, new_code, (i * 10) - 5, 0, 'pezinho');
  END LOOP;

  RETURN earned - existing;
END;
$function$;

CREATE OR REPLACE FUNCTION public.trg_issue_loyalty_rewards()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  PERFORM public.issue_loyalty_rewards(NEW.customer_phone, NEW.customer_name);
  PERFORM public.issue_pezinho_rewards(NEW.customer_phone, NEW.customer_name);
  RETURN NEW;
END;
$function$;

-- cupons de desconto continuam sendo os únicos usados no agendamento
CREATE OR REPLACE FUNCTION public.get_active_reward(_phone text)
 RETURNS TABLE(code text, discount_amount numeric)
 LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $function$
  SELECT r.code, r.discount_amount
  FROM public.loyalty_rewards r
  WHERE r.customer_phone = regexp_replace(_phone, '\D', '', 'g')
    AND r.status = 'active' AND r.reward_type = 'discount'
  ORDER BY r.created_at ASC
  LIMIT 1;
$function$;

CREATE OR REPLACE FUNCTION public.get_reward_by_code(_phone text, _code text)
 RETURNS TABLE(code text, discount_amount numeric, status text)
 LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $function$
  SELECT r.code, r.discount_amount, r.status
  FROM public.loyalty_rewards r
  WHERE r.customer_phone = regexp_replace(coalesce(_phone,''), '\D', '', 'g')
    AND upper(r.code) = upper(trim(coalesce(_code,'')))
    AND r.reward_type = 'discount'
  LIMIT 1;
$function$;

-- progresso agora informa também o bônus do pezinho
DROP FUNCTION IF EXISTS public.get_loyalty_progress(text);
CREATE FUNCTION public.get_loyalty_progress(_phone text)
 RETURNS TABLE(total_services integer, free_services_earned integer, free_services_redeemed integer, available integer, progress integer, goal integer, has_reward boolean, pezinho_available integer, has_pezinho boolean)
 LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $function$
  SELECT
    COALESCE(l.total_services, 0)::int,
    COALESCE(l.free_services_earned, 0)::int,
    COALESCE(l.free_services_redeemed, 0)::int,
    (SELECT count(*) FROM public.loyalty_rewards r WHERE r.customer_phone = q.p AND r.status = 'active' AND r.reward_type = 'discount')::int,
    (COALESCE(l.total_services, 0) % 10)::int,
    10,
    EXISTS (SELECT 1 FROM public.loyalty_rewards r WHERE r.customer_phone = q.p AND r.status = 'active' AND r.reward_type = 'discount'),
    (SELECT count(*) FROM public.loyalty_rewards r WHERE r.customer_phone = q.p AND r.status = 'active' AND r.reward_type = 'pezinho')::int,
    EXISTS (SELECT 1 FROM public.loyalty_rewards r WHERE r.customer_phone = q.p AND r.status = 'active' AND r.reward_type = 'pezinho')
  FROM (SELECT regexp_replace(_phone, '\D', '', 'g') AS p) q
  LEFT JOIN public.loyalty l ON l.customer_phone = q.p;
$function$;

-- admin marca o pezinho como utilizado
CREATE OR REPLACE FUNCTION public.redeem_pezinho_reward(_phone text)
 RETURNS TABLE(valid boolean, message text)
 LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE p text; r public.loyalty_rewards%ROWTYPE;
BEGIN
  p := regexp_replace(coalesce(_phone,''), '\D', '', 'g');
  SELECT * INTO r FROM public.loyalty_rewards
  WHERE customer_phone = p AND reward_type = 'pezinho' AND status = 'active'
  ORDER BY created_at ASC LIMIT 1 FOR UPDATE;

  IF NOT FOUND THEN
    RETURN QUERY SELECT false, 'Nenhum pezinho disponível'::text; RETURN;
  END IF;

  UPDATE public.loyalty_rewards
  SET status = 'used', used_at = now(), updated_at = now()
  WHERE id = r.id;

  RETURN QUERY SELECT true, 'Pezinho de cabelo grátis utilizado'::text;
END;
$function$;

-- gera retroativamente os pezinhos de quem já tem atendimentos concluídos
DO $$
DECLARE rec record;
BEGIN
  FOR rec IN SELECT customer_phone, customer_name FROM public.loyalty LOOP
    PERFORM public.issue_pezinho_rewards(rec.customer_phone, rec.customer_name);
  END LOOP;
END $$;