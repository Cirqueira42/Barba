import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Gift, Search, MessageCircle, Lock, Copy } from "lucide-react";
import { openWhatsApp } from "@/lib/whatsapp";
import { DEFAULT_LOYALTY_CONFIG, fetchLoyaltyConfig, type LoyaltyConfig, formatBRL, validityLine } from "@/lib/loyaltyConfig";

type Reward = {
  id: string;
  customer_phone: string;
  customer_name: string | null;
  code: string;
  discount_amount: number;
  status: string;
  milestone: number;
  used_at: string | null;
  created_at: string;
};

const BOOKING_URL = "https://josebarbearia.lovable.app/agendar";

const LoyaltyRewards = () => {
  const [list, setList] = useState<Reward[]>([]);
  const [search, setSearch] = useState("");
  const [rewardValue, setRewardValue] = useState("7");
  const [savingValue, setSavingValue] = useState(false);
  const [cfg, setCfg] = useState<LoyaltyConfig>(DEFAULT_LOYALTY_CONFIG);
  const [bonusService, setBonusService] = useState(DEFAULT_LOYALTY_CONFIG.bonusServiceName);
  const [validityDays, setValidityDays] = useState("0");
  const [savingExtra, setSavingExtra] = useState(false);
  const savedRef = useRef<string | null>(null);
  const { toast } = useToast();

  const load = async () => {
    const { data } = await (supabase as any)
      .from("loyalty_rewards")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(200);
    setList((data as Reward[]) || []);
  };

  const loadValue = async () => {
    const { data } = await supabase.from("app_settings").select("value").eq("key", "loyalty_reward_value").maybeSingle();
    if (data?.value != null) setRewardValue(String(data.value));
    savedRef.current = data?.value != null ? String(data.value) : "7";
  };

  const loadCfg = async () => {
    const c = await fetchLoyaltyConfig();
    setCfg(c);
    setBonusService(c.bonusServiceName);
    setValidityDays(String(c.validityDays));
  };

  const saveExtra = async () => {
    setSavingExtra(true);
    const days = Math.max(0, Math.round(Number(validityDays) || 0));
    const { error } = await supabase.from("app_settings").upsert([
      { key: "loyalty_bonus_service_name", value: bonusService.trim() as any, updated_at: new Date().toISOString() },
      { key: "loyalty_validity_days", value: days as any, updated_at: new Date().toISOString() },
    ]);
    setSavingExtra(false);
    if (error) toast({ title: "Erro ao salvar", description: error.message, variant: "destructive" });
    else { toast({ title: "Benefícios atualizados ✅", description: "As próximas mensagens já usam a nova configuração." }); loadCfg(); }
  };

  useEffect(() => {
    load();
    loadValue();
    loadCfg();
    const ch = supabase
      .channel("loyalty-rewards-rt")
      .on("postgres_changes", { event: "*", schema: "public", table: "loyalty_rewards" }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  // Salva automaticamente o valor do cupom (vale apenas para os PRÓXIMOS cupons gerados)
  const saveValue = async (raw: string) => {
    const v = Number(String(raw).replace(",", "."));
    if (!Number.isFinite(v) || v < 0) return;
    setSavingValue(true);
    const { error } = await supabase
      .from("app_settings")
      .upsert({ key: "loyalty_reward_value", value: v as any, updated_at: new Date().toISOString() });
    if (!error) {
      savedRef.current = raw;
      loadCfg();
      toast({ title: "Valor salvo ✅", description: `Novos cupons de fidelidade valerão R$ ${v.toFixed(2)}. Cupons já conquistados mantêm o valor original.` });
      load();
    } else {
      toast({ title: "Erro ao salvar", description: error.message, variant: "destructive" });
    }
    setSavingValue(false);
  };


  useEffect(() => {
    if (savedRef.current === null || savedRef.current === rewardValue) return;
    const t = setTimeout(() => {
      const v = Number(String(rewardValue).replace(",", "."));
      if (rewardValue !== "" && Number.isFinite(v)) saveValue(rewardValue);
    }, 900);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rewardValue]);



  const filtered = useMemo(
    () =>
      list.filter(
        (r) =>
          (r.customer_name || "").toLowerCase().includes(search.toLowerCase()) ||
          r.customer_phone.includes(search) ||
          r.code.toLowerCase().includes(search.toLowerCase()),
      ),
    [list, search],
  );

  const activeCount = list.filter((r) => r.status === "active").length;

  const sendCode = (r: Reward) => {
    const phone = r.customer_phone.replace(/\D/g, "");
    const phoneDDI = phone.startsWith("55") ? phone : `55${phone}`;
    const text = `🎉 *PARABÉNS, ${r.customer_name || "cliente"}!* 🎉\n\nVocê completou *${r.milestone || cfg.goal} atendimentos* na *José Barbearia* e liberou o seu *código exclusivo*:\n\n🔐 *${r.code}*\n🎁 Benefício: *${formatBRL(Number(r.discount_amount) || cfg.rewardValue)} de desconto*${validityLine(cfg)}\n\nEsse código é só seu, vale no seu *próximo atendimento* e pode ser usado uma única vez.\n\n👉 É só agendar e digitar o código no campo "Cupom de desconto":\n${BOOKING_URL}\n\nObrigado pela preferência! 🙏💈`;
    openWhatsApp(phoneDDI, text);
  };

  const markUsed = async (r: Reward) => {
    await (supabase as any)
      .from("loyalty_rewards")
      .update({ status: "used", used_at: new Date().toISOString() })
      .eq("id", r.id);
    toast({ title: "Código bloqueado", description: `${r.code} não pode mais ser usado.` });
    load();
  };

  return (
    <div className="bg-card/90 backdrop-blur border border-border rounded-lg p-3 sm:p-4">
      <div className="flex items-center gap-2 mb-3 flex-wrap">
        <Gift className="w-5 h-5 text-primary" />
        <h2 className="text-base sm:text-lg font-bold">Códigos de Fidelidade</h2>
        <Badge variant="outline" className="ml-auto text-[10px]">{activeCount} ativo(s)</Badge>
      </div>

      <div className="mb-3 rounded-lg border border-primary/30 bg-primary/5 p-2.5">
        <label className="text-[11px] font-semibold text-foreground block mb-1">
          Valor do cupom de fidelidade (R$)
        </label>
        <div className="flex items-center gap-2">
          <Input
            inputMode="decimal"
            value={rewardValue}
            onChange={(e) => setRewardValue(e.target.value)}
            className="h-9 text-sm max-w-[120px]"
          />
          <span className="text-[10px] text-muted-foreground">
            {savingValue ? "Salvando..." : "Salva sozinho · vale para os PRÓXIMOS cupons (os já conquistados mantêm o valor)"}
          </span>

        </div>
      </div>

      <div className="mb-3 rounded-lg border border-yellow-400/30 bg-yellow-400/5 p-2.5 space-y-2">
        <p className="text-[11px] font-semibold text-foreground">Bônus do 5º atendimento e validade</p>
        <div className="flex flex-wrap items-center gap-2">
          <Input
            value={bonusService}
            onChange={(e) => setBonusService(e.target.value)}
            placeholder="Nome do serviço bônus"
            className="h-9 text-sm max-w-[200px]"
          />
          <Input
            inputMode="numeric"
            value={validityDays}
            onChange={(e) => setValidityDays(e.target.value)}
            placeholder="Validade (dias)"
            className="h-9 text-sm max-w-[120px]"
          />
          <Button size="sm" className="h-9" onClick={saveExtra} disabled={savingExtra}>
            {savingExtra ? "Salvando..." : "Salvar"}
          </Button>
        </div>
        <p className="text-[10px] text-muted-foreground">
          O bônus aplica 100% de desconto sobre o valor ATUAL do serviço
          {cfg.bonusServicePrice > 0 ? ` (hoje ${formatBRL(cfg.bonusServicePrice)})` : " (cadastre o serviço em Serviços para exibir o valor)"}.
          Validade 0 = sem prazo.
        </p>
      </div>

      <p className="text-[11px] text-muted-foreground mb-3">
        O código é gerado sozinho quando o cliente completa {cfg.goal} atendimentos concluídos. O cliente não vê o
        código nem o valor — você envia manualmente. Depois de usado, fica bloqueado para sempre.
      </p>


      <div className="relative mb-3">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input placeholder="Buscar por nome, telefone ou código..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 h-9 text-sm" />
      </div>

      {filtered.length === 0 ? (
        <p className="text-xs text-muted-foreground text-center py-4">Nenhum código gerado ainda.</p>
      ) : (
        <div className="space-y-2 max-h-80 overflow-auto">
          {filtered.map((r) => (
            <div key={r.id} className={`rounded-lg border p-2.5 ${r.status === "active" ? "border-green-500/50 bg-green-500/5" : "border-border bg-background/40 opacity-70"}`}>
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <div className="min-w-0">
                  <p className="text-sm font-semibold truncate">{r.customer_name || "Cliente"}</p>
                  <p className="text-[10px] text-muted-foreground">📞 {r.customer_phone} · {r.milestone} atendimentos</p>
                </div>
                <Badge className={`text-[10px] shrink-0 ${r.status === "active" ? "bg-green-500/20 text-green-400 border-green-500/30" : r.status === "reserved" ? "bg-amber-500/20 text-amber-400 border-amber-500/30" : "bg-muted text-muted-foreground"}`}>
                  {r.status === "active" ? "Disponível" : r.status === "reserved" ? "Reservado" : "Utilizado"}
                </Badge>
              </div>

              <div className="flex items-center gap-2 mb-2">
                <code className="font-mono font-bold tracking-widest text-primary text-sm bg-background/70 rounded px-2 py-1">{r.code}</code>
                <span className="text-[11px] text-muted-foreground">R$ {Number(r.discount_amount).toFixed(2)}</span>
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-6 w-6 ml-auto"
                  onClick={() => { navigator.clipboard.writeText(r.code); toast({ title: "Código copiado" }); }}
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>

              {r.status === "active" && (
                <div className="flex gap-2">
                  <Button size="sm" className="flex-1 h-8 bg-green-600 hover:bg-green-700 text-white" onClick={() => sendCode(r)}>
                    <MessageCircle className="w-3 h-3 mr-1" /> Enviar no WhatsApp
                  </Button>
                  <Button size="sm" variant="outline" className="h-8" onClick={() => markUsed(r)}>
                    <Lock className="w-3 h-3 mr-1" /> Marcar usado
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default LoyaltyRewards;
