import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { DatabaseZap, Copy, Download, CheckCircle2 } from "lucide-react";
// Carregado via glob para não quebrar o build caso o arquivo não exista no repositório.
const migrationFiles = import.meta.glob("/supabase/schema/migracao-dados.sql", {
  query: "?raw",
  import: "default",
  eager: true,
}) as Record<string, string>;
const migrationSql: string =
  Object.values(migrationFiles)[0] ?? "-- Script de migração não encontrado no pacote do projeto.";

const DataMigration = () => {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(migrationSql);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = migrationSql;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
    toast({ title: "Script copiado!", description: "Cole no SQL Editor do banco NOVO." });
  };

  const download = () => {
    const blob = new Blob([migrationSql], { type: "application/sql" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "migracao-dados.sql";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-start gap-3">
        <DatabaseZap className="h-5 w-5 text-primary mt-0.5 shrink-0" />
        <div>
          <h3 className="font-semibold">Migrar dados do banco antigo</h3>
          <p className="text-sm text-muted-foreground">
            Copia clientes, agendamentos, estrelas de fidelidade, cupons e bônus de pezinho do banco
            antigo para o novo. Pode rodar mais de uma vez sem duplicar nada.
          </p>
        </div>
      </div>

      <ol className="text-xs text-muted-foreground list-decimal pl-5 space-y-1">
        <li>Rode antes o script de estrutura (aba "Código SQL do banco") no banco novo.</li>
        <li>No script abaixo, troque <code className="text-primary">HOST_ANTIGO</code> e <code className="text-primary">SENHA_ANTIGA</code> pelos dados do banco antigo.</li>
        <li>Cole tudo no SQL Editor do banco novo e execute. No final ele mostra a conferência das quantidades.</li>
      </ol>

      <div className="flex flex-wrap gap-2">
        <Button onClick={copy} className="flex-1 min-w-[150px]">
          {copied ? <CheckCircle2 className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
          {copied ? "Copiado!" : "Copiar script"}
        </Button>
        <Button onClick={download} variant="outline" className="flex-1 min-w-[150px]">
          <Download className="h-4 w-4 mr-2" />
          Baixar .sql
        </Button>
      </div>

      <pre className="max-h-80 overflow-auto rounded-lg border border-border bg-muted/40 p-3 text-[11px] leading-relaxed whitespace-pre">
        <code>{migrationSql}</code>
      </pre>
    </div>
  );
};

export default DataMigration;
