import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Database, Copy, Download, CheckCircle2 } from "lucide-react";
// Carregado via glob para não quebrar o build caso o arquivo não exista no repositório.
const schemaFiles = import.meta.glob("/supabase/schema/josebarbearia-schema.sql", {
  query: "?raw",
  import: "default",
  eager: true,
}) as Record<string, string>;
const schemaSql: string =
  Object.values(schemaFiles)[0] ?? "-- Arquivo do schema não encontrado no pacote do projeto.";

const DatabaseSchema = () => {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(schemaSql);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = schemaSql;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
    toast({ title: "Código copiado!", description: "Cole no SQL Editor do seu Supabase." });
  };

  const download = () => {
    const blob = new Blob([schemaSql], { type: "application/sql" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "josebarbearia-schema.sql";
    a.click();
    URL.revokeObjectURL(url);
  };

  const lines = schemaSql.split("\n").length;

  return (
    <div className="space-y-4">
      <div className="flex items-start gap-3">
        <Database className="h-5 w-5 text-primary mt-0.5 shrink-0" />
        <div>
          <h3 className="font-semibold">Código SQL do banco</h3>
          <p className="text-sm text-muted-foreground">
            Estrutura completa (tabelas, RLS, funções e triggers). {lines} linhas.
          </p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <Button onClick={copy} className="flex-1 min-w-[150px]">
          {copied ? <CheckCircle2 className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
          {copied ? "Copiado!" : "Copiar código"}
        </Button>
        <Button onClick={download} variant="outline" className="flex-1 min-w-[150px]">
          <Download className="h-4 w-4 mr-2" />
          Baixar .sql
        </Button>
      </div>

      <pre className="max-h-80 overflow-auto rounded-lg border border-border bg-muted/40 p-3 text-[11px] leading-relaxed whitespace-pre">
        <code>{schemaSql}</code>
      </pre>
    </div>
  );
};

export default DatabaseSchema;
