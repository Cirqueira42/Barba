import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Award, Gift, Search, Star, MessageCircle, Pencil, Check, X, PartyPopper, Plus, Minus, Scissors } from "lucide-react";
import { openWhatsApp } from "@/lib/whatsapp";
import {
  DEFAULT_LOYALTY_CONFIG,
  fetchLoyaltyConfig,
  type LoyaltyConfig,
  formatBRL,
  rewardLabel,
  bonusLabel,
  buildBonusMessage,
  buildRewardMessage,
  buildProgressMessage,
} from "@/lib/loyaltyConfig";

const BOOKING_URL = "https://josebarbearia.lovable.app/agendar";

type LoyaltyRecord = {
  id: string;
  customer_phone: string;
  customer_name: string;
  total_services: number;
  free_services_earned: number;
  free_services_redeemed: number;
};

const GOAL = 10;

type RewardStat = { earned: number; active: number; used: number; pezinhoActive: number; pezinhoUsed: number };

const LoyaltyProgram = () => {
  const [records, setRecords] = useState<LoyaltyRecord[]>([]);
  const [rewardStats, setRewardStats] = useState<Record<string, RewardStat>>({});
  const [search, setSearch] = useState("");
  const [enabled, setEnabled] = useState(true);
  const [cfg, setCfg] = useState<LoyaltyConfig>(DEFAULT_LOYALTY_CONFIG);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    fetchLoyalty();
    fetchEnabled();
    fetchLoyaltyConfig().then(setCfg);
    const channel = supabase
      .channel("loyalty-realtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "loyalty" }, () => fetchLoyalty())
      .on("postgres_changes", { event: "*", schema: "public", table: "loyalty_rewards" }, () => fetchLoyalty())
      .on("postgres_changes", { event: "*", schema: "public", table: "app_settings" }, () => fetchLoyaltyConfig().then(setCfg))
      .on("postgres_changes", { event: "*", schema: "public", table: "services" }, () => fetchLoyaltyConfig().then(setCfg))
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  const fetchEnabled = async () => {
    const { data } = await supabase.from("app_settings").select("value").eq("key", "loyalty_enabled").maybeSingle();
    setEnabled(data?.value === true);
  };


  const toggleEnabled = async (next: boolean) => {
    setEnabled(next);
    const { error } = await supabase.from("app_settings").upsert({ key: "loyalty_enabled", value: next, updated_at: new Date().toISOString() });
    if (error) {
      setEnabled(!next);
      toast({ title: "Erro", description: "Não foi possível salvar.", variant: "destructive" });
    } else {
      toast({ title: next ? "Fidelidade ativada ✅" : "Fidelidade desativada", description: next ? "Os clientes voltam a ver o programa ao agendar." : "O programa não aparece mais para os clientes." });
    }
  };

  const saveCount = async (record: LoyaltyRecord) => {
    const total = Math.max(0, parseInt(editValue, 10) || 0);
    const earned = Math.floor(total / GOAL);
    const { error } = await supabase
      .from("loyalty")
      .update({
        total_services: total,
        free_services_earned: earned,
        free_services_redeemed: Math.min(record.free_services_redeemed, earned),
      })
      .eq("id", record.id);
    setEditingId(null);
    if (error) toast({ title: "Erro", description: "Não foi possível atualizar.", variant: "destructive" });
    else { toast({ title: "Atualizado!", description: `${record.customer_name}: ${total} serviços.` }); fetchLoyalty(); }
  };

  // Ajuste rápido: tira ou adiciona 1 estrela (serviço feito fora do sistema, correção, etc.)
  const adjustStars = async (record: LoyaltyRecord, delta: number) => {
    const total = Math.max(0, record.total_services + delta);
    const earned = Math.floor(total / GOAL);
    const { error } = await supabase
      .from("loyalty")
      .update({
        total_services: total,
        free_services_earned: earned,
        free_services_redeemed: Math.min(record.free_services_redeemed, earned),
      })
      .eq("id", record.id);
    if (error) {
      toast({ title: "Erro", description: "Não foi possível ajustar.", variant: "destructive" });
    } else {
      toast({
        title: delta > 0 ? "⭐ Estrela adicionada" : "Estrela removida",
        description: `${record.customer_name}: ${total} serviço${total !== 1 ? "s" : ""}.`,
      });
      fetchLoyalty();
    }
  };

  const fetchLoyalty = async () => {
    const { data } = await supabase
      .from("loyalty")
      .select("*")
      .order("total_services", { ascending: false });
    if (data) setRecords(data as LoyaltyRecord[]);

    const { data: rw } = await (supabase as any)
      .from("loyalty_rewards")
      .select("customer_phone, status, reward_type");
    const stats: Record<string, RewardStat> = {};
    ((rw as any[]) || []).forEach((x) => {
      const s = (stats[x.customer_phone] ||= { earned: 0, active: 0, used: 0, pezinhoActive: 0, pezinhoUsed: 0 });
      if (x.reward_type === "pezinho") {
        if (x.status === "active") s.pezinhoActive += 1;
        else if (x.status === "used") s.pezinhoUsed += 1;
        return;
      }
      s.earned += 1;
      if (x.status === "active") s.active += 1;
      else if (x.status === "used") s.used += 1;
    });
    setRewardStats(stats);
  };

  const statFor = (phone: string): RewardStat =>
    rewardStats[phone] || { earned: 0, active: 0, used: 0, pezinhoActive: 0, pezinhoUsed: 0 };

  const usePezinho = async (record: LoyaltyRecord) => {
    const { data, error } = await (supabase as any).rpc("redeem_pezinho_reward", { _phone: record.customer_phone });
    const res = Array.isArray(data) ? data[0] : data;
    if (error || !res?.valid) {
      toast({ title: "Erro", description: res?.message || "Não foi possível usar o pezinho.", variant: "destructive" });
    } else {
      toast({ title: "✂️ Bônus utilizado!", description: `${record.customer_name} usou 1 ${cfg.bonusServiceName} grátis.` });
    }
    fetchLoyalty();
  };

  const redeemFree = async (record: LoyaltyRecord) => {
    const { data: rw } = await (supabase as any).rpc("get_active_reward", { _phone: record.customer_phone });
    const reward = Array.isArray(rw) ? rw[0] : rw;
    if (!reward?.code) {
      toast({ title: "Sem cupom ativo", description: "Este cliente não possui cupom disponível.", variant: "destructive" });
      return;
    }
    const { data, error } = await (supabase as any).rpc("redeem_loyalty_code", {
      _phone: record.customer_phone,
      _code: reward.code,
    });
    const res = Array.isArray(data) ? data[0] : data;
    if (error || !res?.valid) {
      toast({ title: "Erro", description: res?.message || "Não foi possível resgatar.", variant: "destructive" });
    } else {
      toast({ title: "🎉 Cupom utilizado!", description: `${record.customer_name} usou o cupom ${reward.code} (${formatBRL(Number(reward.discount_amount) || cfg.rewardValue)}).` });
    }
    fetchLoyalty();
  };

  const notifyClient = (record: LoyaltyRecord) => {
    const st = statFor(record.customer_phone);
    const available = st.active;
    const progress = record.total_services % GOAL;
    const remaining = Math.max(GOAL - progress, 0);
    const phone = record.customer_phone.replace(/\D/g, "");
    const phoneWithDDI = phone.startsWith("55") ? phone : `55${phone}`;

    let text = "";
    if (st.pezinhoActive > 0 && available === 0) {
      text = buildBonusMessage(cfg, record.customer_name, st.pezinhoActive, BOOKING_URL);
    } else if (available > 0) {
      text = buildRewardMessage(cfg, record.customer_name, available, BOOKING_URL);
    } else {
      text = buildProgressMessage(cfg, record.customer_name, record.total_services, remaining, BOOKING_URL);
    }
    openWhatsApp(phoneWithDDI, text);
  };


  const filtered = records.filter((r) =>
    r.customer_name.toLowerCase().includes(search.toLowerCase()) ||
    r.customer_phone.includes(search)
  );

  return (
    <div className="bg-card border border-border rounded-lg p-4 sm:p-6">
      <div className="flex flex-wrap items-center gap-2 mb-3">
        <Award className="w-5 h-5 text-primary" />
        <h2 className="text-lg font-bold text-foreground">Programa de Fidelidade</h2>
        <Badge variant="outline" className="ml-auto text-xs">
          A cada {GOAL} atendimentos = {rewardLabel(cfg)}
        </Badge>
        <p className="w-full text-[11px] text-muted-foreground">
          ⭐ Só conta estrela em serviços de <strong className="text-foreground">R$ 30,00</strong> ou mais — vale para o bônus de {cfg.bonusStep} e para o de {GOAL} atendimentos.
        </p>

      </div>

      <div className="flex items-center justify-between gap-3 mb-4 rounded-lg border border-border bg-background p-3">
        <div>
          <p className="text-sm font-semibold text-foreground">{enabled ? "Ativado" : "Desativado"}</p>
          <p className="text-[11px] text-muted-foreground">
            {enabled ? "Os clientes veem o programa ao agendar." : "Os clientes não veem o programa ao agendar."}
          </p>
        </div>
        <Switch checked={enabled} onCheckedChange={toggleEnabled} />
      </div>


      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Buscar cliente por nome ou telefone..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {filtered.length === 0 ? (
        <p className="text-center text-muted-foreground py-6 text-sm">
          Nenhum cliente no programa ainda. Os clientes são adicionados automaticamente quando um serviço é concluído.
        </p>
      ) : (
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {filtered.map((r) => {
            const progress = r.total_services % GOAL;
            const st = statFor(r.customer_phone);
            const available = st.active;
            const progressPercent = (progress / GOAL) * 100;


            return (
              <div key={r.id} className={`bg-background border rounded-lg p-3 ${available > 0 ? "border-green-500/60 shadow-[0_0_0_1px_rgba(34,197,94,0.25)]" : "border-border"}`}>
                {available > 0 && (
                  <div className="mb-2 rounded-md bg-green-500/15 border border-green-500/30 px-2 py-1.5 text-[11px] text-green-400 font-semibold flex items-center gap-1">
                    <PartyPopper className="w-3.5 h-3.5" />
                    Meta batida! Dê os parabéns — {rewardLabel(cfg)} liberado.
                  </div>
                )}
                {st.pezinhoActive > 0 && (
                  <div className="mb-2 rounded-md bg-yellow-400/15 border border-yellow-400/30 px-2 py-1.5 text-[11px] text-yellow-400 font-semibold flex items-center gap-1">
                    <Scissors className="w-3.5 h-3.5" />
                    Bônus de {cfg.bonusStep} atendimentos: {bonusLabel(cfg, st.pezinhoActive)} disponível
                  </div>
                )}
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <p className="font-semibold text-foreground text-sm">{r.customer_name}</p>
                    <p className="text-xs text-muted-foreground">📞 {r.customer_phone}</p>
                  </div>
                  <div className="text-right">
                    {editingId === r.id ? (
                      <div className="flex items-center gap-1 justify-end">
                        <Input
                          type="number"
                          min={0}
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          className="h-7 w-16 text-xs px-2"
                        />
                        <Button size="icon" className="h-7 w-7" onClick={() => saveCount(r)}><Check className="w-3 h-3" /></Button>
                        <Button size="icon" variant="outline" className="h-7 w-7" onClick={() => setEditingId(null)}><X className="w-3 h-3" /></Button>
                      </div>
                    ) : (
                      <button
                        onClick={() => { setEditingId(r.id); setEditValue(String(r.total_services)); }}
                        className="text-xs text-muted-foreground flex items-center gap-1 ml-auto hover:text-primary"
                      >
                        Total: {r.total_services} serviços <Pencil className="w-3 h-3" />
                      </button>
                    )}
                    {available > 0 && (
                      <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">
                        <Gift className="w-3 h-3 mr-1" />
                        {available} cupom{available > 1 ? "ns" : ""} de {formatBRL(cfg.rewardValue)}
                      </Badge>
                    )}
                  </div>

                </div>

                <p className="text-[10px] text-muted-foreground mb-2">
                  Cupons conquistados: <strong className="text-foreground">{st.earned}</strong> · ativos:{" "}
                  <strong className="text-green-400">{st.active}</strong> · utilizados:{" "}
                  <strong className="text-foreground">{st.used}</strong>
                </p>



                {/* Progress bar */}
                <div className="mb-2">
                  <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
                    <span>{progress}/{GOAL} para o próximo benefício ({rewardLabel(cfg)})</span>
                    <span>{Math.round(progressPercent)}%</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div
                      className="bg-primary h-2 rounded-full transition-all"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                  {/* Stars + ajuste manual */}
                   <div className="flex flex-wrap items-center gap-2 mt-1">
                     <div className="grid grid-cols-5 min-[360px]:grid-cols-10 gap-0.5">
                      {Array.from({ length: GOAL }).map((_, i) => (
                        <Star
                          key={i}
                          className={`w-3 h-3 ${
                            available > 0 && progress === 0
                              ? "text-green-500 fill-green-500"
                              : i >= progress
                                ? "text-muted-foreground/30"
                                : i === 4
                                  ? "text-yellow-400 fill-yellow-400"
                                  : "text-primary fill-primary"
                          }`}
                        />
                      ))}
                    </div>
                    <div className="flex items-center gap-1 ml-auto">
                      <Button
                        size="icon"
                        variant="outline"
                        className="h-6 w-6"
                        title="Tirar 1 estrela"
                        disabled={r.total_services <= 0}
                        onClick={() => adjustStars(r, -1)}
                      >
                        <Minus className="w-3 h-3" />
                      </Button>
                      <Button
                        size="icon"
                        variant="outline"
                        className="h-6 w-6"
                        title="Adicionar 1 estrela (serviço feito fora do sistema)"
                        onClick={() => adjustStars(r, 1)}
                      >
                        <Plus className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    size="sm"
                    onClick={() => notifyClient(r)}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                  >
                    <MessageCircle className="w-3 h-3 mr-1" />
                    {available > 0 ? "Parabenizar no WhatsApp" : "Notificar no WhatsApp"}
                  </Button>
                  {available > 0 && (
                    <Button
                      size="sm"
                      onClick={() => redeemFree(r)}
                      className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                    >
                      <Gift className="w-3 h-3 mr-1" />
                      Usar {formatBRL(cfg.rewardValue)}
                    </Button>
                  )}
                  {st.pezinhoActive > 0 && (
                    <Button
                      size="sm"
                      onClick={() => usePezinho(r)}
                      className="flex-1 bg-yellow-500 hover:bg-yellow-600 text-black"
                    >
                      <Scissors className="w-3 h-3 mr-1" />
                      Usar {cfg.bonusServiceName}
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default LoyaltyProgram;
