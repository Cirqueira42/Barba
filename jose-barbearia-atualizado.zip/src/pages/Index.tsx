import Seo from "@/components/Seo";
import Hero from "@/components/Hero";
import HighlightCarousel from "@/components/HighlightCarousel";
import Products from "@/components/Products";
import Services from "@/components/Services";
import Gallery from "@/components/Gallery";
import Reviews from "@/components/Reviews";
import Location from "@/components/Location";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <main className="min-h-screen bg-background">
      <Seo
        title="José Barbearia | Barbearia em Guariba - SP"
        description="Barbearia em Guariba/SP. Agende online corte, barba e sobrancelha com o José e conheça nossos produtos."
        path="/"
      />
      <Hero />
      <HighlightCarousel />
      <Gallery />
      <Services />
      <Products />
      <Reviews />

      <Location />
      <Footer />
    </main>
  );
};

export default Index;
