import { supabase } from "@/integrations/supabase/client";

/**
 * Configuração dinâmica do Programa de Fidelidade.
 * Nenhum valor fica fixo no código: tudo é lido do painel ADM (app_settings)
 * e do cadastro de serviços. Se o ADM mudar o valor, as próximas mensagens
 * já saem com a nova configuração.
 */

export const LOYALTY_GOAL = 10;
export const LOYALTY_BONUS_STEP = 5;

export type LoyaltyConfig = {
  /** Valor (R$) do cupom liberado a cada ciclo de 10 atendimentos */
  rewardValue: number;
  /** Nome do serviço oferecido como bônus no 5º atendimento */
  bonusServiceName: string;
  /** Preço ATUAL do serviço bônus (0 se não cadastrado) */
  bonusServicePrice: number;
  /** Prazo de validade (em dias) do benefício. 0 = sem prazo */
  validityDays: number;
  goal: number;
  bonusStep: number;
};

export const DEFAULT_LOYALTY_CONFIG: LoyaltyConfig = {
  rewardValue: 7,
  bonusServiceName: "Pezinho de Cabelo",
  bonusServicePrice: 0,
  validityDays: 0,
  goal: LOYALTY_GOAL,
  bonusStep: LOYALTY_BONUS_STEP,
};

const num = (v: unknown, fallback: number) => {
  const n = Number(typeof v === "string" ? v.replace(",", ".") : v);
  return Number.isFinite(n) ? n : fallback;
};

export const fetchLoyaltyConfig = async (): Promise<LoyaltyConfig> => {
  const { data } = await supabase
    .from("app_settings")
    .select("key, value")
    .in("key", ["loyalty_reward_value", "loyalty_bonus_service_name", "loyalty_validity_days"]);

  const map: Record<string, any> = {};
  (data || []).forEach((r: any) => { map[r.key] = r.value; });

  const bonusServiceName =
    typeof map.loyalty_bonus_service_name === "string" && map.loyalty_bonus_service_name.trim()
      ? map.loyalty_bonus_service_name.trim()
      : DEFAULT_LOYALTY_CONFIG.bonusServiceName;

  let bonusServicePrice = 0;
  const { data: svc } = await supabase
    .from("services")
    .select("price")
    .ilike("name", bonusServiceName)
    .maybeSingle();
  if (svc) bonusServicePrice = Number((svc as any).price) || 0;

  return {
    rewardValue: num(map.loyalty_reward_value, DEFAULT_LOYALTY_CONFIG.rewardValue),
    bonusServiceName,
    bonusServicePrice,
    validityDays: Math.max(0, Math.round(num(map.loyalty_validity_days, 0))),
    goal: LOYALTY_GOAL,
    bonusStep: LOYALTY_BONUS_STEP,
  };
};

export const formatBRL = (v: number) =>
  `R$ ${Number(v || 0).toFixed(2).replace(".", ",")}`;

/** Texto curto do benefício de 10 atendimentos, sempre com o valor atual */
export const rewardLabel = (cfg: LoyaltyConfig, valueOverride?: number) =>
  `${formatBRL(valueOverride ?? cfg.rewardValue)} de desconto`;

/** Texto curto do bônus do 5º atendimento, sempre com o serviço/valor atual */
export const bonusLabel = (cfg: LoyaltyConfig, qty = 1) => {
  const base = `${cfg.bonusServiceName} GRÁTIS`;
  const priceInfo = cfg.bonusServicePrice > 0 ? ` (valor normal ${formatBRL(cfg.bonusServicePrice)} · 100% de desconto)` : "";
  return qty > 1 ? `${qty}x ${base}${priceInfo}` : `${base}${priceInfo}`;
};

export const validityLine = (cfg: LoyaltyConfig) =>
  cfg.validityDays > 0 ? `\n⏳ Você tem ${cfg.validityDays} dias para utilizar seu bônus.` : "";

/** Mensagem do bônus do 5º atendimento */
export const buildBonusMessage = (
  cfg: LoyaltyConfig,
  name: string,
  qty: number,
  bookingUrl: string,
) =>
  `🎉 *Parabéns, ${name}!*\n\nVocê completou *${cfg.bonusStep} atendimentos*!\n\nSeu bônus está liberado:\n✂️ *${bonusLabel(cfg, qty)}*${validityLine(cfg)}\n\nObrigado pela preferência! ⭐\n\n👉 Agendar: ${bookingUrl}`;

/** Mensagem do bônus do 10º atendimento (1 ou mais cupons) */
export const buildRewardMessage = (
  cfg: LoyaltyConfig,
  name: string,
  qty: number,
  bookingUrl: string,
  valueOverride?: number,
) => {
  const benefit = qty > 1
    ? `${qty} cupons de *${rewardLabel(cfg, valueOverride)}* cada`
    : `1 cupom de *${rewardLabel(cfg, valueOverride)}*`;
  return `🎉 *PARABÉNS, ${name}!* 🎉\n\nVocê completou *${cfg.goal} atendimentos* na *José Barbearia*!\n\nSeu bônus está liberado:\n🎁 ${benefit}${validityLine(cfg)}\n\n👉 Agendar: ${bookingUrl}\n\nObrigado pela preferência! 🙏`;
};

/** Mensagem de progresso (ainda não bateu a meta) */
export const buildProgressMessage = (
  cfg: LoyaltyConfig,
  name: string,
  total: number,
  remaining: number,
  bookingUrl: string,
) =>
  `Olá, ${name}! 💈\n\n⭐ *José Barbearia — Programa de Fidelidade*\n\nVocê já fez *${total} atendimento${total !== 1 ? "s" : ""}* com a gente!\n\nFaltam apenas *${remaining} atendimento${remaining !== 1 ? "s" : ""}* pra você liberar *${rewardLabel(cfg)}* 🎉\n\nAgende já: ${bookingUrl}\n\nObrigado pela preferência! 🙏`;
