// Lógica única de disponibilidade da agenda (blocos de 10 minutos).
// A disponibilidade é calculada SOMENTE pela DURAÇÃO do serviço (nunca pelo preço).
import {
  BusinessHours,
  getDayHours,
  weekdayOf,
  timeToMinutes,
  slotsForDate,
} from "./businessHours";

export const STEP = 10;
// Intervalo técnico entre atendimentos já usado pelo sistema
export const BUFFER = 10;

export type SlotStatus = "livre" | "agendado" | "passou" | "bloqueado" | "sem_espaco";

export type BookedRange = { appointment_time: string; duration_minutes: number };
export type BlockedEntry = { blocked_date: string; blocked_time: string | null };

export type SlotInfo = { time: string; available: boolean; reason: SlotStatus };

type Args = {
  businessHours: BusinessHours;
  date: string;
  booked: BookedRange[];
  blocked: BlockedEntry[];
  duration: number;
  /** menor duração entre os serviços ativos (para detectar "buracos" inúteis) */
  minServiceDuration?: number;
  /** minutos atuais quando a data é hoje (para marcar horários que já passaram) */
  nowMinutes?: number | null;
};

/** Blocos de 10 min ocupados por agendamentos existentes (com buffer) ou bloqueados no ADM */
const buildOccupied = (date: string, booked: BookedRange[], blocked: BlockedEntry[]) => {
  const occupied = new Set<number>();
  for (const b of booked) {
    const start = timeToMinutes(b.appointment_time);
    const end = start + (b.duration_minutes || 30) + BUFFER;
    for (let m = start; m < end; m += STEP) occupied.add(m);
  }
  for (const s of blocked) {
    if (s.blocked_date !== date) continue;
    if (s.blocked_time) occupied.add(timeToMinutes(s.blocked_time));
  }
  return occupied;
};

export const computeSlots = ({
  businessHours,
  date,
  booked,
  blocked,
  duration,
  minServiceDuration = STEP,
  nowMinutes = null,
}: Args): SlotInfo[] => {
  // Dia inteiro bloqueado no ADM
  if (blocked.some((s) => s.blocked_date === date && s.blocked_time === null)) return [];

  const grid = slotsForDate(businessHours, date, STEP);
  if (grid.length === 0) return [];

  const day = getDayHours(businessHours, weekdayOf(date));
  const closeMin = timeToMinutes(day.close);
  const lunchStart = timeToMinutes(day.lunch_start);
  const lunchEnd = timeToMinutes(day.lunch_end);
  const hasLunch = lunchEnd > lunchStart;

  const gridSet = new Set(grid.map(timeToMinutes));
  const occupied = buildOccupied(date, booked, blocked);

  const isFreeBlock = (m: number) => gridSet.has(m) && !occupied.has(m);

  // Um horário só termina dentro do expediente e sem atravessar o almoço
  const fitsInWorkingHours = (start: number, dur: number) => {
    const end = start + dur;
    if (end > closeMin) return false;
    if (hasLunch && start < lunchStart && end > lunchStart) return false;
    return true;
  };

  const canStart = (start: number, dur: number) => {
    if (!fitsInWorkingHours(start, dur)) return false;
    for (let m = start; m < start + dur; m += STEP) {
      if (!isFreeBlock(m)) return false;
    }
    return true;
  };

  // Sequências contínuas de blocos livres menores que o menor serviço = "buracos" inúteis
  const uselessGap = new Set<number>();
  const minDur = Math.max(STEP, minServiceDuration || STEP);
  let run: number[] = [];
  const flush = () => {
    if (run.length > 0 && run.length * STEP < minDur) run.forEach((m) => uselessGap.add(m));
    run = [];
  };
  const gridMins = grid.map(timeToMinutes);
  for (let i = 0; i < gridMins.length; i++) {
    const m = gridMins[i];
    const contiguous = i === 0 || gridMins[i - 1] + STEP === m;
    if (!contiguous) flush();
    if (isFreeBlock(m)) run.push(m);
    else flush();
  }
  flush();

  return grid.map((t) => {
    const m = timeToMinutes(t);
    if (nowMinutes != null && m <= nowMinutes) return { time: t, available: false, reason: "passou" as const };
    if (occupied.has(m)) return { time: t, available: false, reason: "agendado" as const };
    if (uselessGap.has(m)) return { time: t, available: false, reason: "sem_espaco" as const };
    if (!canStart(m, duration)) return { time: t, available: false, reason: "sem_espaco" as const };
    return { time: t, available: true, reason: "livre" as const };
  });
};

export const isStartAvailable = (args: Args & { time: string }): boolean => {
  const slots = computeSlots(args);
  const found = slots.find((s) => s.time === args.time);
  return !!found?.available;
};
